package com.example.network_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
