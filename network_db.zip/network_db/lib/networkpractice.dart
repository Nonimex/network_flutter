import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class NetworkPractice extends StatefulWidget{
  NetworkPractice({super.key});
  @override
  State<NetworkPractice> createState() => _NetworkPractice();


}


class _NetworkPractice extends State<NetworkPractice>{

  String title = '';
  String url = 'https://jsonplaceholder.typicode.com/todos/1';

  @override
  void initState(){
    super.initState();
    getData();
  }


  Future<void> getData() async{
    final response = Uri.parse(url);
    final getApi = await http.get(response);



  }


  @override
  Widget build(BuildContext context){
    return Scaffold();
  }
}