import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:network_db/networksimplepage.dart';

void main() {
  runApp( MyApp());

}


class MyApp extends StatelessWidget{

  MyApp({super.key});

  @override
  Widget build(BuildContext context){
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "Network + db",
      home: NetworkSimplePage(),
    );


  }

}


