import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class NetworkSimplePage extends StatefulWidget {
  const NetworkSimplePage({super.key});

  @override
  State<NetworkSimplePage> createState() => _NetworkSimplePageState();
}

class _NetworkSimplePageState extends State<NetworkSimplePage> {

  String getTitleOfApi = '';
  bool isCompleted = false;

  @override
  void initState(){
    super.initState();
    getData();

  }

  Future<void> getData() async{
    final url = Uri.parse('https://jsonplaceholder.typicode.com/todos/1');
    final response = await http.get(url);

    if (response.statusCode == 200){
      final data = jsonDecode(response.body);
      setState(() {
        getTitleOfApi = data['title'];
        isCompleted = data['completed'];
      });
    }
    else {
      setState(() {
        getTitleOfApi = 'Error: ${response.statusCode}';
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Networking - Paso 1'),
      ),
      body: Center(
        child: Column(
          children: [
            Text(getTitleOfApi),
            Text(isCompleted ? 'Completado ' : 'Incompleto' ),
          ],
        )

      ),
    );
  }
}
